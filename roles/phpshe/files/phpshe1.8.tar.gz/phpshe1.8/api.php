<?php
include('common.php');

if (is_file("{$pe['path']}module/{$module}/{$mod}.php")) {
	include("{$pe['path']}module/{$module}/{$mod}.php");
}
else {
	pe_404();
}
pe_result();
?>