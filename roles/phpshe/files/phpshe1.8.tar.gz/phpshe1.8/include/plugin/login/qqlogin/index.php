<?php
include("../../../../common.php");
require_once("API/qqConnectAPI.php");
$login3['jump'] = $_g_jump ? $_g_jump : $pe['host'];
pe_set_session('login3', $login3);
$qc = new QC();
$qc->qq_login();

