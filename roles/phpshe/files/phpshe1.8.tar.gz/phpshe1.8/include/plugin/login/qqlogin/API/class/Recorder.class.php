<?php
/* PHP SDK
 * @version 2.0.0
 * @author connect@qq.com
 * @copyright © 2013, Tencent Corporation. All rights reserved.
 */

require_once(CLASS_PATH."ErrorCase.class.php");
class Recorder{
    private static $data;
    private $inc;
    private $error;

    public function __construct(){
		global $pe, $cache_setting;
        $this->error = new ErrorCase();

        //-------读取配置文件
        //$incFileContents = file(ROOT."comm/inc.php");
        //$incFileContents = $incFileContents[1];
        //$this->inc = json_decode($incFileContents);
		//var_dump($this->inc);
        $cache_setting = cache::get('setting');
		$config['appid'] = $cache_setting['login_qq_appid']; 
		$config['appkey'] = $cache_setting['login_qq_appkey']; 
		$config['callback'] = "{$pe['host']}include/plugin/login/qqlogin/callback.php"; 
		$config['scope'] = 'get_user_info'; 
		$config['errorReport'] = true; 
		$config['storageType'] = 'file'; 
		$config['host'] = 'localhost'; 
		$config['user'] = 'root'; 
		$config['password'] = 'root'; 
		$config['database'] = 'test'; 
		$this->inc= json_decode(json_encode($config));
		
        if(empty($this->inc)){
            $this->error->showError("20001");
        }
        if(empty($_SESSION['QC_userData'])){
            self::$data = array();
        }else{
            self::$data = $_SESSION['QC_userData'];
        }
    }

    public function write($name,$value){
        self::$data[$name] = $value;
    }

    public function read($name){
        if(empty(self::$data[$name])){
            return null;
        }else{
            return self::$data[$name];
        }
    }

    public function readInc($name){
        if(empty($this->inc->$name)){
            return null;
        }else{
            return $this->inc->$name;
        }
    }

    public function delete($name){
        unset(self::$data[$name]);
    }

    function __destruct(){
        $_SESSION['QC_userData'] = self::$data;
    }
}
