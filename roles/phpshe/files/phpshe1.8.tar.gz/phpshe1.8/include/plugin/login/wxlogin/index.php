<?php
include("../../../../common.php");
$callback = urlencode("{$pe['host']}include/plugin/login/wxlogin/callback.php?sessid={$_g_sessid}");
//网页扫码登录
if (!pe_mobile()) {
	$login3['jump'] = $_g_jump ? $_g_jump : $pe['host'];
	pe_set_session('login3', $login3);
	pe_goto("https://open.weixin.qq.com/connect/qrconnect?appid={$cache_setting['login_wx_appid']}&redirect_uri={$callback}&response_type=code&scope=snsapi_login&state=wx_pc_login#wechat_redirect");
}
//公众号登录
else {
	pe_goto("https://open.weixin.qq.com/connect/oauth2/authorize?appid={$cache_setting['wechat_appid']}&redirect_uri={$callback}&response_type=code&scope=snsapi_userinfo&state=wx_gzh_login@{$_g_sessid}#wechat_redirect");
}








	
	