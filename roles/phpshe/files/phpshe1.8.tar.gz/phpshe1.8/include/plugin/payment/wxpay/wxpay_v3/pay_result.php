<?php
include('../../../../common.php');
$pay_id = pe_dbhold($_g_id);
$info = $db->pe_select('pay', array('pay_id'=>$pay_id));
if ($info['order_pstate']) {
	$url = pay_jump($pay_id);
	$data['url'] = $url;
	pe_apidata(array('code'=>1, 'data'=>$data));
}
else {
	pe_apidata(array('code'=>0));		
}
?>