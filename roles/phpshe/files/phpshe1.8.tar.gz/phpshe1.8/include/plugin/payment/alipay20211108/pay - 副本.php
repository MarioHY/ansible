<?php
/* *
 * 功能：即时到账交易接口接入页
 * 版本：3.4
 * 修改日期：2016-03*08
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。

 *************************注意*****************
 
 *如果您在接口集成过程中遇到问题，可以按照下面的途径来解决
 *1、开发文档中心（https://doc.open.alipay.com/doc2/detail.htm?spm=a219a.7629140.0.0.KvddfJ&treeId=62&articleId=103740&docType=1）
 *2、商户帮助中心（https://cshall.alipay.com/enterprise/help_detail.htm?help_id=473888）
 *3、支持中心（https://support.open.alipay.com/alipay/support/index.htm）

 *如果想使用扩展功能,请按文档要求,自行添加到parameter数组即可。
 **********************************************
 */

include('../../../../common.php');
require_once("alipay.config.php");
require_once("lib/alipay_submit.class.php");








$post['app_id'] = $alipay_config['alipay_appid'];
$post['method'] = 'alipay.trade.wap.pay';
$post['format'] = 'JSON';
$post['return_url'] = ;
$post['charset'] = 'utf-8';
$post['sign_type'] = 'RSA2';
$post['sign'] = ;
$post['timestamp'] = ;
$post['version'] = '1.0';
$post['notify_url'] = ;
$post['biz_content'] = ;

//$post['biz_content']['body'] = '';
$post['biz_content']['subject'] = $info['order_name'];
$post['biz_content']['out_trade_no'] = $info['pay_id'];
$post['biz_content']['timeout_express'] = '60m';
//$post['biz_content']['time_expire'] = '';
$post['biz_content']['total_amount'] = $info['order_money'];
//$post['biz_content']['auth_token'] = '';
$post['biz_content']['goods_type'] = 1;
$post['biz_content']['quit_url'] = ;
$post['biz_content']['passback_params'] = ;
$post['biz_content']['product_code'] = 'QUICK_WAP_PAY';
//$post['biz_content']['promo_params'] = ;

$json = pe_curl_post('https://openapi.alipay.com/gateway.do', $post);
var_dump($json);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>支付宝即时到账交易接口接口</title>
</head>
<body>
<?php
$order_id = pe_dbhold($_g_id);
$order = $db->pe_select(order_table($order_id), array('order_id'=>$order_id));

/**************************请求参数**************************/

//商户订单号，商户网站订单系统中唯一订单号，必填
$out_trade_no = $order['order_id'];

//订单名称，必填
$subject = $order['order_name'];

//付款金额，必填
$total_fee = $order['order_money'];

//商品描述，可空
$body = $order['order_text'];

/************************************************************/

//构造要请求的参数数组，无需改动
$parameter = array(
	"service"       => $alipay_config['service'],
	"partner"       => $alipay_config['partner'],
	"seller_id"  => $alipay_config['seller_id'],
	"payment_type"	=> $alipay_config['payment_type'],
	"notify_url"	=> $alipay_config['notify_url'],
	"return_url"	=> $alipay_config['return_url'],
	"anti_phishing_key"=>$alipay_config['anti_phishing_key'],
	"exter_invoke_ip"=>$alipay_config['exter_invoke_ip'],
	"out_trade_no"	=> $out_trade_no,
	"subject"	=> $subject,
	"total_fee"	=> $total_fee,
	"body"	=> $body,
	"_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
	//其他业务参数根据在线开发文档，添加参数.文档地址:https://doc.open.alipay.com/doc2/detail.htm?spm=a219a.7629140.0.0.kiX33I&treeId=62&articleId=103740&docType=1
    //如"参数名"=>"参数值"
);
if ($pe['mobile']) $parameter['app_pay'] = 'Y';


//建立请求
$alipaySubmit = new AlipaySubmit($alipay_config);
echo $html = $alipaySubmit->buildRequestForm($parameter,"get", "确认");
?>
</body>
</html>