<?php
return unserialize('a:3:{s:7:"balance";a:7:{s:10:"payment_id";s:1:"1";s:12:"payment_name";s:12:"余额支付";s:12:"payment_type";s:7:"balance";s:12:"payment_desc";s:54:"使用帐户余额支付，只有会员才能使用。";s:14:"payment_config";b:0;s:13:"payment_state";s:1:"1";s:12:"payment_logo";s:74:"http://localhost/phpshe/1.8/qijian/include/plugin/payment/balance/logo.png";}s:4:"bank";a:7:{s:10:"payment_id";s:1:"4";s:12:"payment_name";s:12:"转账汇款";s:12:"payment_type";s:4:"bank";s:12:"payment_desc";s:90:"通过线下汇款方式支付，汇款帐号：建设银行 621700254000005xxxx 刘某某";s:14:"payment_config";a:1:{s:9:"bank_text";s:168:"请将款项汇款至以下账户：
建设银行 621700254000005xxxx 刘某某
工商银行 621700254000005xxxx 刘某某
农业银行 621700254000005xxxx 刘某某";}s:13:"payment_state";s:1:"1";s:12:"payment_logo";s:71:"http://localhost/phpshe/1.8/qijian/include/plugin/payment/bank/logo.png";}s:8:"adminpay";a:2:{s:12:"payment_name";s:12:"管理代付";s:12:"payment_type";s:8:"adminpay";}}');
?>