<?php include(pe_tpl('header.html'));?>
<div class="width980" style="position:relative">
	<div class="fenlei_box">
		<?php foreach((array)$cache_category_arr[0] as $k=>$v):?>
		<?php $i++;?>
		<div class="fenlei_li fenlei_li_f <?php if($i>11):?>fenlei_li_more<?php endif;?>">
			<div class="fenlei_h3">
				<a href="<?php echo pe_url('product/list/'.$k) ?>" title="<?php echo $v['category_name'] ?>"><?php echo $v['category_name'] ?></a>
				<i></i>
			</div>
			<?php if(is_array($cache_category_arr[$k])):?>
			<div class="js_right" style="display:none">
				<?php foreach((array)$cache_category_arr[$k] as $kk=>$vv):?>
				<div class="fl_s">
					<div class="fl fl_s1"><a href="<?php echo pe_url('product/list/'.$kk) ?>" title="<?php echo $vv['category_name'] ?>"><strong><?php echo $vv['category_name'] ?></strong> ></a></div>
					<div class="fl fl_s2">
						<?php foreach((array)$cache_category_arr[$kk] as $kkk=>$vvv):?>
						<a href="<?php echo pe_url('product/list/'.$kkk) ?>" title="<?php echo $vvv['category_name'] ?>"><?php echo $vvv['category_name'] ?></a>
						<?php endforeach;?>
						<div class="clear"></div>
					</div>
					<div class="clear"></div>
				</div>
				<?php endforeach;?>
			</div>
			<?php endif;?>
		</div>
		<?php endforeach;?>
	</div>
</div>
<div class="swiper-container">
	<div class="swiper-wrapper">
		<?php foreach($info['ad_list'] as $v):?>
		<div class="swiper-slide" style="height:500px;background:url(<?php echo $v['ad_logo'] ?>) no-repeat center 0;" ></div>
		<?php endforeach;?>
	</div>
	<div class="swiper-pagination"></div>
</div>
<div class="clear"></div>
<div class="content">
	<div class="notice_list">
		<h3 class="fl">网站公告</h3>
		<ul class="fl">
			<?php foreach($info['notice_list'] as $k=>$v):?>
			<li><i>●</i><a href="<?php echo pe_url('article/'.$v['article_id']) ?>" title="<?php echo $v['article_name'] ?>" target="_blank"><?php echo $v['article_name'] ?></a></li>
			<?php endforeach;?>
		</ul>
		<a class="more fr" href="<?php echo pe_url('article/list/1') ?>">查看更多</a>
		<div class="clear"></div>	
	</div>
	<div class="clear"></div>
	<?php if($miaosha['huodong_id']):?>
	<div class="mrms">
		<span class="fl">每日秒杀</span>
		<a href="<?php echo pe_url('huodong/miaosha') ?>" class="more fr">更多 ></a>
		<div class="clear"></div>
	</div>
	<div class="mab20">
		<div class="ms_left">
			<div class="ms_cred"><?php echo $miaosha['time'] ?> 场</div>
			<div class="ms_sd"><img src="<?php echo $pe['host_tpl'] ?>image/ms_sd.png"></div>
			<div class="font16"><?php echo $miaosha['desc'] ?></div>
			<div class="ms_time" id="huodong_time" endtime="<?php echo $miaosha['etime'] ?>">
				<span class="jstime_h">00</span>:<span class="jstime_m">00</span>:<span class="jstime_s">00</span>
			</div>
		</div>
		<?php foreach($info['miaosha_list'] as $k=>$v):?>
		<div class="mx_pro" <?php if(($k+1)%4==0):?>style="padding-right:0; border-right:0"<?php endif?>>
			<a href="<?php echo pe_url('product/'.$v['product_id']) ?>" title="<?php echo $v['product_name'] ?>" target="_blank">
			<div class="ms_pro">
				<img src="<?php echo $pe['host_tpl'] ?>image/pixel.gif" data-url="<?php echo $v['product_logo'] ?>" title="<?php echo $v['product_name'] ?>" width="198" height="198" class="js_imgload" />				
			</div>
			<div class="ms_name mat15"><?php echo $v['product_name'] ?></div>
			<div class="ms_fname"><?php echo $v['huodong_tag'] ?></div>
			<div class="ms_money">
				<span class="money3 mar10">¥<?php echo $v['product_money'] ?></span>
				<s class="c999 font14">¥<?php echo $v['product_ymoney'] ?></s>
			</div>
			<div class="clear"></div>
			</a>
		</div>
		<?php endforeach;?>
		<div class="clear"></div>
	</div>
	<?php endif;?>
	<?php foreach($info['category_list'] as $category):?>
	<div class="prolist_tt">
		<h3 class="fl"><?php echo $category['category_name'] ?></h3>
		<?php if(is_array($cache_category_arr[$category['category_id']])):?>
		<?php foreach($cache_category_arr[$category['category_id']] as $k=>$v):?>
		<a href="<?php echo pe_url('product/list/'.$k) ?>" title="<?php echo $v['category_name'] ?>" target="_blank"><?php echo $v['category_name'] ?></a>
		<?php endforeach;?>
		<?php endif;?>
		<a href="<?php echo pe_url('product/list/'.$category['category_id']) ?>" title="<?php echo $category['category_name'] ?>" target="_blank" class="more">更多 ></a>
	</div>
	<div class="clear"></div>
	<!--<div class="leftad">
		<img src="<?php echo $pe['host_tpl'] ?>image/ad2.jpg">
	</div>-->
	<?php foreach($category['product_list'] as $k=>$v):?>
	<div class="prolist" <?php if(($k+1)%5==0):?>style="margin-right:0"<?php endif;?>>
		<a href="<?php echo pe_url('product/'.$v['product_id']) ?>" title="<?php echo $v['product_name'] ?>" target="_blank">
		<div class="prolist_logo">
			<img src="<?php echo $pe['host_tpl'] ?>image/pixel.gif" data-url="<?php echo $v['product_logo'] ?>" title="<?php echo $v['product_name'] ?>" class="js_imgload" />
			<?php if($v['huodong_tag']):?><div class="prolist_tag"><?php echo $v['huodong_tag'] ?></div><?php endif;?>
		</div>
		<p class="prolist_name"><?php echo $v['product_name'] ?></p>
		<p class="ms_money">
			<span class="money3">¥<?php echo $v['product_money'] ?></span> 
		</p>
		<div class="clear"></div>
		</a>
	</div>
	<?php endforeach;?>
	<div class="clear"></div>
	<?php endforeach;?>
	<div class="link_list">
		<div class="link_tt"><span>友情链接</span></div>
		<div class="link_name">
			<?php foreach($cache_link as $v):?>
			<a href="<?php echo $v['link_url'] ?>" target="_blank" title="<?php echo $v['link_name'] ?>"><?php echo $v['link_name'] ?></a>
			<?php endforeach;?>
		</div>
	</div>
</div>
<link type="text/css" rel="stylesheet" href="<?php echo $pe['host'] ?>include/plugin/swiper/swiper.min.css" />
<script type="text/javascript" src="<?php echo $pe['host'] ?>include/plugin/swiper/swiper.min.js"></script>
<script type="text/javascript">
$(function(){
    var swiper = new Swiper('.swiper-container', {
    	autoplay: true,
		pagination: {
			el: '.swiper-pagination',
			dynamicBullets: true,
		},
    });
	pe_jstime("#huodong_time", '<?php echo time() ?>');
	$(".fenlei_li").hover(
		function(){	
			$(".fenlei_li").removeClass("fenlei_li_sel");
			$(this).addClass("fenlei_li_sel");
			$(".fenlei_li").find(".js_right").hide();
			var h = $(this).index() * 40;
			$(this).find(".js_right").css("top", "-"+h+"px").show();
		},
		function(){
			$(".fenlei_li").removeClass("fenlei_li_sel");
			$(".fenlei_li").find(".js_right").hide();	
		}
	)
	$(".fenlei_box").hover(
		function(){	
			$(this).addClass("sel")
		},
		function(){
			$(this).removeClass("sel")	
		}
	)
})
</script>
<?php include(pe_tpl('footer.html'));?>