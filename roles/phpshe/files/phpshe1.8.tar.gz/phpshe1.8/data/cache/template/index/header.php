<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $seo['title'] ?></title>
<meta name="keywords" content="<?php echo $seo['keywords'] ?>" />
<meta name="description" content="<?php echo $seo['description'] ?>" />
<link rel="shortcut icon" type="image/ico" href="<?php echo $pe['host'] ?>favicon.ico">
<link type="text/css" rel="stylesheet" href="<?php echo $pe['host_tpl'] ?>css/style.css" />
<script type="text/javascript" src="<?php echo $pe['host'] ?>include/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $pe['host'] ?>include/js/global.js"></script>
<script type="text/javascript" src="<?php echo $pe['host'] ?>include/js/arttpl.js"></script>
<script type="text/javascript" src="<?php echo $pe['host'] ?>include/plugin/layer/layer.js"></script>
<script type="text/javascript">
var host = "<?php echo $pe['host'] ?>";
var pe_nowurl = '<?php echo pe_nowurl() ?>';
var pe_token = '<?php echo $pe_token ?>';
</script>
</head>
<body>
<div class="pagetop">
	<div class="width980">
		<span class="fl"><?php echo $cache_setting['web_title'] ?>欢迎您！</span>
		<div class="fr pagetop_r">
			<?php if(pe_login('user')):?>
			您好：<a href="<?php echo $pe['host'] ?>user.php" style="color:#DF002F;padding:0;border:0"><?php echo $user['user_name'] ?></a>
			<a href="<?php echo $pe['host'] ?>user.php?mod=do&act=logout" title="退出">退出</a>
			<?php else:?>
			<a href="<?php echo $pe['host'] ?>user.php?mod=do&act=login&<?php echo pe_jump() ?>" title="登录">登录</a>
			<a href="<?php echo $pe['host'] ?>user.php?mod=do&act=register&<?php echo pe_jump() ?>" title="注册">注册</a>
			<?php endif;?>
			<a href="<?php echo $pe['host'] ?>user.php?mod=order" title="我的订单" class="scj">我的订单</a>
			<a href="<?php echo $pe['host'] ?>user.php?mod=sign" title="签到有礼">签到有礼</a>
			<a href="<?php echo pe_url('article/list/help') ?>" title="帮助中心" style="border-right:0;">帮助中心</a>
		</div>
		<div class="clear"></div>
	</div>
</div>
<div class="width980">
<?php echo ad_show('pc', 'header') ?>
<?php if($mod=='index'):?><?php echo ad_show('pc', 'index_header') ?><?php endif;?>
</div>
<div class="head_box">
	<div class="width980">
		<div class="logo fl"><a href="<?php echo $pe['host'] ?>" title="<?php echo $cache_setting['web_name'] ?>"><img src="<?php echo pe_thumb($cache_setting['web_logo']) ?>" alt="<?php echo $cache_setting['web_name'] ?>" height="45" /></a></div>
		<ul class="head_nav fl">
		<li><a href="<?php echo $pe['host'] ?>" title="首页" class="sy"><span></span>首页</a></li>
		<?php foreach((array)$cache_menu['pc'] as $v):?>
		<li><a href="<?php echo $v['menu_url'] ?>" title="<?php echo $v['menu_name'] ?>" target="_blank"><?php echo $v['menu_name'] ?></a></li>
		<?php endforeach;?>
		</ul>
		<div class="sear fr">				
			<form method="get" action="<?php echo $pe['host'] ?>index.php">
			<input type="hidden" name="mod" value="product" />
			<input type="hidden" name="act" value="list" />
			<input type="text" name="keyword" value="<?php echo htmlspecialchars($_g_keyword) ?>" class="fl searinput" placeholder="<?php echo $cache_setting['web_hotword'] ?>" />
			<input type="submit" class="fr sear_btn" value=" " />
			</form>
			<div class="clear"></div>
		</div>
		<div class="clear"></div>
	</div>
</div>
<div class="clear"></div>