<div class="clear"></div>
<div class="width980">
<?php echo ad_show('pc', 'footer') ?>
<?php if($mod=='index'):?><?php echo ad_show('pc', 'index_footer') ?><?php endif;?>
</div>
<div class="celan">
	<a href="<?php echo pe_url('cart') ?>">
		<div class="ico_gwc"><i></i><?php if($cart_num=cart_num()):?><span class="gwc_num js_cartnum"><?php echo $cart_num ?></span><?php endif;?></div>
		<div class="font14 mat8">购物车</div>
	</a>
	<a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $cache_setting['kefu_qq'] ?>&site=qq&menu=yes" target="_blank">
		<div class="ico_kf"><i></i></div>
		<div class="font14 mat8">在线客服</div>
	</a>
	<!--<a href="<?php echo $pe['host_h5'] ?>">
		<div class="ico_app"><i></i></div>
		<div class="font14 mat8">APP下载</div>
	</a>-->
	<a href="javascript:right_scrolltop();" class="topback"><i></i></a>
</div>
<div class="foot">
	<div class="foot_sm">
		<ul>
		<li>
			<i class="i_1"></i>
			<h3>自营保正品</h3>
			<p>现货自营 正品保证</p>
		</li>
		<li>
			<i class="i_2"></i>
			<h3>全场免运费</h3>
			<p>不限品类 满99免邮</p>
		</li>
		<li>
			<i class="i_3"></i>
			<h3>发货如闪电</h3>
			<p>极速发货 航空直达</p>
		</li>
		<li>
			<i class="i_4"></i>
			<h3>退货有保障</h3>
			<p>开箱验货 30天退换</p>
		</li>
		</ul>
		<div class="clear"></div>
	</div>
	<div class="bottom_link">
		<div class="border_link">
			<?php foreach($cache_article_category_arr['help'] as $v):?>
			<?php if(++$help_index>5)break;?>
			<?php $info_list = $db->pe_selectall('article', array('category_id'=>$v['category_id']))?>
			<div class="item_1 fl">
				<h3><?php echo $v['category_name'] ?></h3>
				<ul>
					<?php foreach($info_list as $vv):?>
					<li><a href="<?php echo pe_url('article/'.$vv['article_id']) ?>" title="<?php echo $vv['article_name'] ?>"><?php echo $vv['article_name'] ?></a></li>
					<?php endforeach;?>
				</ul>
			</div>
			<?php endforeach;?>
			<div class="foot_telnum">
				<p><span><?php echo $cache_setting['kefu_phone'] ?></span></p>
				<span class="font14 cfen">周一 至 周五　8:00-18:00</span>
				<div class="mat10">
				<img class="fl" src="<?php echo pe_thumb($cache_setting['web_qrcode']) ?>">
				<div class="x_sm_text">关注公众号</div>
				<div class="clear"></div>
				</div>
			</div>
			<div class="clear"></div>
		</div>
	</div>
	<div class="subnav">
		Copyright <span class="num">©</span> <?php echo $cache_setting['web_copyright'] ?> All Rights Reserved <?php echo $cache_setting['web_icp'] ?> <?php echo $cache_setting['web_tongji'] ?>&nbsp;
		Powered by <a href="http://www.phpshe.com" target="_blank" title="PHPSHE商城系统">phpshe<?php echo $ini['phpshe']['version'] ?></a>
	</div>
</div>
<script type="text/javascript" src="<?php echo $pe['host'] ?>include/js/jquery.scrollLoading.js"></script>
<script type="text/javascript">
$(function(){
	$("img.js_imgload").scrollLoading();
});
function right_scrolltop() {
	$("body,html").animate({"scrollTop":0});	
}
pe_loadscript("<?php echo $pe['host'] ?>api.php?mod=cron");
pe_loadscript("<?php echo $pe['host'] ?>api.php?mod=cron&act=buyer");
</script>
</body>
</html>