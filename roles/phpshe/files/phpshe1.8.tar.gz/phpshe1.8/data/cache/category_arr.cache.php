<?php
return unserialize('a:1:{i:0;a:1:{i:1;a:5:{s:11:"category_id";s:1:"1";s:12:"category_pid";s:1:"0";s:13:"category_name";s:0:"";s:13:"category_logo";s:0:"";s:14:"category_state";s:1:"1";}}}');
?>